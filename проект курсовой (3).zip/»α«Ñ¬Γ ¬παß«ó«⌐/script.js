const modeButton = document.querySelector('.light-dark');
const body = document.body;
function toggleTheme() {
    body.classList.toggle('dark-theme');
    const isDarkTheme = body.classList.contains('dark-theme');
    localStorage.setItem('theme', isDarkTheme ? 'dark' : 'light');
}
document.addEventListener('DOMContentLoaded', function () {
    const savedTheme = localStorage.getItem('theme');

    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
    }
});
modeButton.addEventListener('click', toggleTheme);

const cardItems = document.querySelectorAll('.card-item');
const modal = document.getElementById('myModal');
const modalImg = document.getElementById('modalImage');
const closeModal = document.querySelector('.close');

cardItems.forEach((cardItem, index) => {
    cardItem.addEventListener('click', () => {
        modal.style.display = 'block';
        if (index === 0) {
            modalImg.src = 'img.main/allphoto.png';
        } else if (index === 1) {
            modalImg.src = 'img.main/group.png';
        } else if (index === 2) {
            modalImg.src = 'img.main/allgruzovik.png';
        } else if (index === 3) {
            modalImg.src = 'img.main/allwine.png';
        } else if (index === 4) {
            modalImg.src = 'img.main/allphotograph.png';
        } else if (index === 5) {
            modalImg.src = 'img.main/thissite.png';
        }
    });
});
closeModal.addEventListener('click', () => {
    modal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});








